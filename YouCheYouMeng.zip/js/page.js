// JavaScript Document





/**
* @name		:mianInit
* @author	:Nice
* @dependent:总初始化
*/
function mianInit(){
    //调试 禁用
//    alert('x');
    document.write("<script src=\"http://172.16.1.131:81/con/assets/js/f5.js\"><\script>");
}
mianInit();
/* @end **/



/**
* @name		:名称
* @author	:作者
* @dependent:描述
*/

/* @end **/

/**
* @name		:
* @author	:Nice
* @version	:
* @type		:基类
* @explain	:
* @relating	:
* @dependent:
*/

/* @end **/